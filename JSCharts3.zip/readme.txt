Thank you for using JScharts 3.02 (www.jscharts.com)
Please read the following note before starting


JSCharts 3.02 Free
The free JS Charts version is fully customizable but watermarked.
To remove the watermark you need a domain key.


License Note
Shall not be used by any customer to create third party applications/components that may compete with Smartketer by providing the third party consumer with the possibility to have the embedded component within an editor application.
To get the source codes, special customizations licenses please contact our sales department at sales [at] jumpeyecomponents.com.
JSCharts by JumpeyeComponents, Smartketer LLC is licensed under a Creative Commons Attribution-Noncommercial-No Derivative Works 3.0 Unported License.
Based on a work at www.jscharts.com. 


Start using the JSCharts Note
For details, please read the Jscharts.pdf manual.


For more details please visit our website www.jscharts.com